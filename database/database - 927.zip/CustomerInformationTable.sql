create table CustomerInformationtable(
CustomerID text primary key,
CustomerName text not null,
CustomerSex text default 'unknown',
CustomerAge integer default 'unknown' check (CustomerAge > 0),
CustomerBirthday text default 'unknown',
CustomerPhone text default 'unknown',
CustomerEmail text default 'unknown',
CustomerAddress text default 'unknown',
CustomerRegisterTime text default current_timestamp
);

insert into CustomerInformationtable(CustomerID,CustomerName)
VALUES('00000020','武康县');
insert into CustomerInformationtable(CustomerID,CustomerName)
VALUES('00000021','斯当东');
insert into CustomerInformationtable(CustomerID,CustomerName)
VALUES('00000022','第三代');
insert into CustomerInformationtable(CustomerID,CustomerName)
VALUES('00000023','所思所');
insert into CustomerInformationtable(CustomerID,CustomerName)
VALUES('00000024','鲮鲤科');

