CREATE TABLE UserInformationtable(
UserID text primary key,
UserName text default 'unkonwn',
UserPassword text not null,
UserLimit text not null,
UserSex text default 'unkonwn',
UserAge integer check (UserAge > 0),
UserBirthday text default 'unknown',
UserPhone text default 'unknown',
UserEmail text default 'unknown',
UserAddress text default 'unknown',
UserRegisterTime text default current_timestamp
);

insert into UserInformationtable(UserID,UserName,UserPassword,UserLimit,UserSex,UserAge,UserBirthday,UserPhone,UserEmail,UserAddress)
VALUES('47','王凯旋','111111','管理员','男',21,'1994年7月18日','13073565915','2654189525@qq.com','中国贵州遵义');
insert into UserInformationtable(UserID,UserName,UserPassword,UserLimit,UserSex,UserAge,UserBirthday,UserPhone,UserEmail,UserAddress)
VALUES('1218','陈刚容','123456','管理员','女',20,'1995年12月18日','18375203954','1573811240@qq.com','中国贵州遵义');
insert into UserInformationtable(UserID,UserName,UserPassword,UserLimit,UserSex,UserAge,UserBirthday,UserPhone,UserEmail,UserAddress)
VALUES('0812','王凯军','1333456','管理员','男',18,'1993年12月18日','18075203954','1473811240@qq.com','中国贵州遵义');
insert into UserInformationtable(UserID,UserName,UserPassword,UserLimit,UserSex,UserAge,UserBirthday,UserPhone,UserEmail,UserAddress)
VALUES('122','李志刚','1333456','普通用户','男',20,'1993年9月6日','15383463721','1473811240@qq.com','中国辽宁铁岭');

insert into UserInformationtable(UserID,UserName,UserPassword,UserLimit,UserSex,UserAge,UserBirthday,UserPhone,UserEmail,UserAddress)
VALUES('123','崔文伟','1333456','普通用户','男',20,'1993年9月6日','13383431273','1473843240@qq.com','中国海南');

insert into UserInformationtable(UserID,UserName,UserPassword,UserLimit,UserSex,UserAge,UserBirthday,UserPhone,UserEmail,UserAddress)
VALUES('124','李镇远','1333456','普通用户','男',20,'1993年9月6日','15110350996','1473832240@qq.com','中国江苏');

insert into UserInformationtable(UserID,UserName,UserPassword,UserLimit,UserSex,UserAge,UserBirthday,UserPhone,UserEmail,UserAddress)
VALUES('125','彭衍','1333456','普通用户','男',20,'1993年9月6日','15513252728','1473811440@qq.com','中国湖南');

insert into UserInformationtable(UserID,UserName,UserPassword,UserLimit,UserSex,UserAge,UserBirthday,UserPhone,UserEmail,UserAddress)
VALUES('126','尉景端','1333456','普通用户','男',20,'1993年9月6日','15035438297','1475674740@qq.com','中国山西运城');

