create table ProviderInformationtable(
ProviderID text primary key,
ProviderPhone text not null,
ProviderAddress text default 'unknown',
ProviderEmail text default 'unknown'
);

insert into ProviderInformationtable(ProviderID,ProviderPhone)
VALUES('1338346','19837987912');
insert into ProviderInformationtable(ProviderID,ProviderPhone)
VALUES('133218346','19837987912');
insert into ProviderInformationtable(ProviderID,ProviderPhone)
VALUES('133834326','19837987912');
insert into ProviderInformationtable(ProviderID,ProviderPhone)
VALUES('13383346','19837987912');

