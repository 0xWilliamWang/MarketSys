PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE CommodityInformationtable(
CommodityID text primary key,
CommodityName text not null,
CommoditySpecification text not null,
CommodityPrice integer not null,
CommodityWholesaleprice integer not null,
CommodityRetailPrice integer not null,
CommodityShelfLife integer  not null,
ProviderID text  not null,
CommodityShelfEndTime text  not null
);
INSERT INTO "CommodityInformationtable" VALUES('00020042','多比兔围兜','个',54.7,104.7,114.7,'180天','00000001','2019年9月10日');
INSERT INTO "CommodityInformationtable" VALUES('000702005','嘟嘟连体衣','件',97.5,147.5,157.5,'180天','00000001','2019年9月10日');
INSERT INTO "CommodityInformationtable" VALUES('0008056','多比兔高领套','件',69.6,119.6,129.6,'180天','00000001','2019年9月10日');
INSERT INTO "CommodityInformationtable" VALUES('0010038','900贝登金装1段','听',237,287,297,'180天','00000001','2019年9月10日');
INSERT INTO "CommodityInformationtable" VALUES('0010072','味全优+3','包',133,183,193,'180天','00000001','2019年9月10日');
CREATE TABLE CustomerInformationtable(
CustomerID text primary key,
CustomerName text not null,
CustomerSex text default 'unknown',
CustomerAge integer default 'unknown' check (CustomerAge > 0),
CustomerBirthday text default 'unknown',
CustomerPhone text default 'unknown',
CustomerEmail text default 'unknown',
CustomerAddress text default 'unknown',
CustomerRegisterTime text default current_timestamp
);
INSERT INTO "CustomerInformationtable" VALUES('00000020','武康县','unknown','unknown','unknown','unknown','unknown','unknown','2015-09-27 06:25:58');
INSERT INTO "CustomerInformationtable" VALUES('00000021','斯当东','unknown','unknown','unknown','unknown','unknown','unknown','2015-09-27 06:25:58');
INSERT INTO "CustomerInformationtable" VALUES('00000022','第三代','unknown','unknown','unknown','unknown','unknown','unknown','2015-09-27 06:25:58');
INSERT INTO "CustomerInformationtable" VALUES('00000023','所思所','unknown','unknown','unknown','unknown','unknown','unknown','2015-09-27 06:25:58');
INSERT INTO "CustomerInformationtable" VALUES('00000024','鲮鲤科','unknown','unknown','unknown','unknown','unknown','unknown','2015-09-27 06:25:58');
CREATE TABLE IndentInformationtable(
UserID text primary key,
IndentCrreatTime text default current_timestamp,
IndentObject text not null,
IndentMan text not null,
IndentCost integer not null check(IndentCost > 0),
IndentNumber integer not null check(IndentCost > 0),
ProviderID text not null
);
INSERT INTO "IndentInformationtable" VALUES('1338346','2015-09-27 06:26:05','908冠军宝贝3','王凯旋',4000,111,'123');
INSERT INTO "IndentInformationtable" VALUES('345666','2015-09-27 06:26:05','特价束口棉裤','王凯旋',4000,111,'123');
INSERT INTO "IndentInformationtable" VALUES('34566','2015-09-27 06:26:05','亨氏混合果泥','王凯旋',4000,111,'123');
INSERT INTO "IndentInformationtable" VALUES('18345666','2015-09-27 06:26:05','亨氏香甜胡萝卜泥','王凯旋',4000,111,'123');
CREATE TABLE ProviderInformationtable(
ProviderID text primary key,
ProviderPhone text not null,
ProviderAddress text default 'unknown',
ProviderEmail text default 'unknown'
);
INSERT INTO "ProviderInformationtable" VALUES('1338346','19837987912','unknown','unknown');
INSERT INTO "ProviderInformationtable" VALUES('133218346','19837987912','unknown','unknown');
INSERT INTO "ProviderInformationtable" VALUES('133834326','19837987912','unknown','unknown');
INSERT INTO "ProviderInformationtable" VALUES('13383346','19837987912','unknown','unknown');
CREATE TABLE UserInformationtable(
UserID text primary key,
UserName text not null,
UserPassword text not null,
UserLimit text not null,
UserSex text default 'unkonwn',
UserAge integer check (UserAge > 0),
UserBirthday text default 'unknown',
UserPhone text default 'unknown',
UserEmail text default 'unknown',
UserAddress text default 'unknown',
UserRegisterTime text default current_timestamp
);
INSERT INTO "UserInformationtable" VALUES('47','王凯旋','111111','管理员','男',21,'1994年7月18日','13073565915','2654189525@qq.com','中国贵州遵义','2015-09-27 06:26:23');
INSERT INTO "UserInformationtable" VALUES('1218','陈刚容','123456','管理员','女',20,'1995年12月18日','18375203954','1573811240@qq.com','中国贵州遵义','2015-09-27 06:26:23');
INSERT INTO "UserInformationtable" VALUES('0812','王凯军','1333456','管理员','男',18,'1993年12月18日','18075203954','1473811240@qq.com','中国贵州遵义','2015-09-27 06:26:23');
INSERT INTO "UserInformationtable" VALUES('122','李志刚','1333456','普通用户','男',20,'1993年9月6日','15383463721','1473811240@qq.com','中国辽宁铁岭','2015-09-27 06:26:23');
INSERT INTO "UserInformationtable" VALUES('123','崔文伟','1333456','普通用户','男',20,'1993年9月6日','13383431273','1473843240@qq.com','中国海南','2015-09-27 06:26:23');
INSERT INTO "UserInformationtable" VALUES('124','李镇远','1333456','普通用户','男',20,'1993年9月6日','15110350996','1473832240@qq.com','中国江苏','2015-09-27 06:26:23');
INSERT INTO "UserInformationtable" VALUES('125','彭衍','1333456','普通用户','男',20,'1993年9月6日','15513252728','1473811440@qq.com','中国湖南','2015-09-27 06:26:23');
INSERT INTO "UserInformationtable" VALUES('126','尉景端','1333456','普通用户','男',20,'1993年9月6日','15035438297','1475674740@qq.com','中国山西运城','2015-09-27 06:26:23');
COMMIT;
