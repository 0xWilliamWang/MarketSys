create table CommodityInformationtable(
CommodityID text primary key,
CommodityName text not null,
CommoditySpecification text not null,
CommodityPrice integer not null,
CommodityWholesaleprice integer not null,
CommodityRetailPrice integer not null,
CommodityShelfLife integer  not null,
ProviderID text  not null,
CommodityShelfEndTime text  not null
);

insert into CommodityInformationtable(CommodityID,CommodityName,CommoditySpecification,CommodityPrice,CommodityWholesaleprice,CommodityRetailPrice,CommodityShelfLife,ProviderID,CommodityShelfEndTime)
VALUES('00020042','多比兔围兜','个',54.7,104.7,114.7,'180天','00000001','2019年9月10日');

insert into CommodityInformationtable(CommodityID,CommodityName,CommoditySpecification,CommodityPrice,CommodityWholesaleprice,CommodityRetailPrice,CommodityShelfLife,ProviderID,CommodityShelfEndTime)
VALUES('000702005','嘟嘟连体衣','件',97.5,147.5,157.5,'180天','00000001','2019年9月10日');

insert into CommodityInformationtable(CommodityID,CommodityName,CommoditySpecification,CommodityPrice,CommodityWholesaleprice,CommodityRetailPrice,CommodityShelfLife,ProviderID,CommodityShelfEndTime)
VALUES('0008056','多比兔高领套','件',69.6,119.6,129.6,'180天','00000001','2019年9月10日');

insert into CommodityInformationtable(CommodityID,CommodityName,CommoditySpecification,CommodityPrice,CommodityWholesaleprice,CommodityRetailPrice,CommodityShelfLife,ProviderID,CommodityShelfEndTime)
VALUES('0010038','900贝登金装1段','听',237,287,297,'180天','00000001','2019年9月10日');

insert into CommodityInformationtable(CommodityID,CommodityName,CommoditySpecification,CommodityPrice,CommodityWholesaleprice,CommodityRetailPrice,CommodityShelfLife,ProviderID,CommodityShelfEndTime)
VALUES('0010072','味全优+3','包',133,183,193,'180天','00000001','2019年9月10日');




