create table IndentInformationtable(
UserID text primary key,
IndentCrreatTime text default current_timestamp,
IndentObject text not null,
IndentMan text not null,
IndentCost integer not null check(IndentCost > 0),
IndentNumber integer not null check(IndentCost > 0),
ProviderID text not null
);


insert into IndentInformationtable(UserID,IndentObject,IndentMan,IndentCost,IndentNumber,ProviderID)
VALUES('1338346','908冠军宝贝3','王凯旋',4000,111,'123');
insert into IndentInformationtable(UserID,IndentObject,IndentMan,IndentCost,IndentNumber,ProviderID)
VALUES('345666','特价束口棉裤','王凯旋',4000,111,'123');
insert into IndentInformationtable(UserID,IndentObject,IndentMan,IndentCost,IndentNumber,ProviderID)
VALUES('34566','亨氏混合果泥','王凯旋',4000,111,'123');
insert into IndentInformationtable(UserID,IndentObject,IndentMan,IndentCost,IndentNumber,ProviderID)
VALUES('18345666','亨氏香甜胡萝卜泥','王凯旋',4000,111,'123');

